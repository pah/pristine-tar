// Utils.cs
// 
// Copyright © 2008 David Paleino <d.paleino@gmail.com>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

using System;

namespace GnomeRDP
{
    /// <summary>
    /// Generic utilities class
    /// </summary>
    public class Utils
    {
        /// <summary>
        /// Compares two "version strings", both in the form of "x.x(.x)*".
        /// </summary>
        /// <param name="a">
        /// A <see cref="System.String"/>
        /// </param>
        /// <param name="b">
        /// A <see cref="System.String"/>
        /// </param>
        /// <returns>
        /// A <see cref="System.Integer"/>. -1 if a is smaller than b, 0 if they're equal, 1 if a is greater than b.
        /// </returns>
        public static int CompareVersion(string a, string b) {
            //char[] split = {'.'};
            //string[] a_array = a.Split(split);
            //string[] b_array = b.Split(split);
            
            //Console.WriteLine(a_array);
            //Console.WriteLine(b_array);
            return 1;
        }
    }
}
