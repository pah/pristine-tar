// VNC.cs
// 
// Copyright © 2008 David Paleino <d.paleino@gmail.com>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

using System;

namespace GnomeRDP
{
    public class VNC
    {
        private string _password = "";
        
        public enum Backend {
            XTightVNCViewer = 0,
            RealVNC,
            XVNC4Viewer
        }
        
        public void SetPassword(string Password) {
            this._password = Password;
            Console.WriteLine("Password: {0}", Password);
        }
        
        public bool SetBackend(Backend Name) {
            return false;
        }
        
        public Backend DetectBackend() {
            return Backend.XTightVNCViewer;
        }
        
        public void Connect(string Host) {
        }
    }
}
