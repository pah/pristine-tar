void game_loop(void);
void begin_game(void);
