void enact_commands(void);
void continue_secondary_burst(int a);

