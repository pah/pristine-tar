void init_tiles(void);
void make_tile_map(int x, int y);
void open_eyes(void);


