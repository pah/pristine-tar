void init_display(void);
void prepare_display(void);

