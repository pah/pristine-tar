
void init_level(void);
void run_level(void);
void finish_level(void);

