void init_menus_once_only(void);

void menu_loop(void);
