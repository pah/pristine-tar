
These are the make files for the Amiga version of UNACE.

It contains a version without support for encrypted files, because of USA
export restrictions for programs which have strong encryption. If you need an
Amiga version that can handle .ACE files with encrypted files in the archive,
an Amiga version with decryption routines is available from the homepage of
Marcel Lemke (http://members.aol.com/mlemke6413/ace.html) on the World Wide
Web.

Note: This program needs a lot of memory (upto 1 Mega byte) to decompress
some .ACE files. This depends on the used dictionary size (-d<size> switch)
when the archive was created.


Wilfred van Velzen 

Fido : 2:280/464.12
Email: wilfred@aobh.xs4all.nl

