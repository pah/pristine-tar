/* ------------------------------------------------------------------------ */
/*  ML - 01/2004: changed licence to GPL                                    */
/* ------------------------------------------------------------------------ */ 

#ifndef __uac_comm_h
#define __uac_comm_h


#include "declare.h"

extern INT  comm_cpr_size;
extern CHAR *comm;

void comment_out(CHAR *top);


#endif /* __uac_comm_h */

