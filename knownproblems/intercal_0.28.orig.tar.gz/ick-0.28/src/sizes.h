/* sizes.h -- constants defining the numeric base for INTERCAL variations */

extern int ick_Base;
extern int ick_Small_digits;
extern int ick_Large_digits;
extern unsigned int ick_Max_small;
extern unsigned int ick_Max_large;

/* sizes.h ends here */
