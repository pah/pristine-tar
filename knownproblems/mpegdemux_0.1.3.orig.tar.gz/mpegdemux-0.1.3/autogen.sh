#!/bin/sh

autoconf
rm -r -f "autom4te.cache"
