#define L_WARNING "Aviso: "
#define L_ONLINE " en lnea "
#define L_F "\n"
#define L_ZONEOPEN "No se pudo abrir el archivo de zona para la zona "
#define L_FATAL "Error fatal en el archivo de zona "
#define L_ABOUT_THIS " (abortando este archivo de zona)"
#define L_S_ZONE "Error de sintaxis en el archivo de zona "
#define L_L " ("
#define L_R ")"
#define L_FIRST_SOA "El primer registro en el archivo de zona csv1 debe ser un
registro SOA."
#define L_ZONE "Zona: "
#define L_SECOND_SOA "Segundo SOA en el archivo de zona"
#define L_ABORT " (abortando archivo de zona)"
#define L_DDIP_WARN "IP con punto para NS, CNAME, o MX no funciona en algunos servidores DNS"
/* These need to be translated. */
#define L_INITCSV "csv1 hash is not correctly initialized.\nMake sure to have cs
v1 initialized with csv1 = {}"
#define L_BADZONE "A zone file is incorrectly named.  All zone files must end with a dot, e.g.\ncsv1[\"example.com.\"] = \"filename\".\nHere is the line in the mararc with the problem: "
#define L_LINE_NUMBER "Line number "
#define L_TOO_LONG " is too long in file "

