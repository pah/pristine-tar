These MaraRC files test various forms of server redirections (where subtrees
use different name servers)
