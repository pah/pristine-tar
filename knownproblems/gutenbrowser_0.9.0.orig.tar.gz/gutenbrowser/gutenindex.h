//
// C++ Interface: gutenindex
//
// Description:
//
//
// Author: Lorn Potter <lorn.potter@gmail.com>, (C) 2006
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef GUTENINDEX_H
#define GUTENINDEX_H
#include <QtGui>

class QStringList;

/**
	@author Lorn Potter <lorn.potter@gmail.com>
*/
class gutenIndex: public QObject {
        Q_OBJECT
public:
    gutenIndex();

    ~gutenIndex();

    QList<QStringList> getLibrary();
    bool parseIndex();
    void downloadNewIndex();
    
private:
    QString author, authBox, title;
    QList<QStringList> libraryList;

    bool parseRdf();
    bool addAuthor();
    void addItems();
    QString gutindexFilename;

protected slots:

private:
    QString findPath(QString &);
    QString findOldPath(const QString &, const QString&);
    bool unzipIndex(const QString &file);

};

#endif
