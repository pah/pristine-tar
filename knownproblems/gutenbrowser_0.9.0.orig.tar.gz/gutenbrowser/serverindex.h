//
// C++ Interface: serverindex
//
// Description: 
//
//
// Author: Lorn Potter <lorn.potter@gmail.com>, (C) 2006
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef SERVERINDEX_H
#define SERVERINDEX_H

#include <QtGui>

/**
	@author Lorn Potter <lorn.potter@gmail.com>
*/
class serverIndex : public QObject
{
    Q_OBJECT
public:
    serverIndex();

    ~serverIndex();
    
    QList<QStringList> getServers();
    bool parseServerFile();

private slots:
    
    void downloadMirrorsFile();
};

#endif
