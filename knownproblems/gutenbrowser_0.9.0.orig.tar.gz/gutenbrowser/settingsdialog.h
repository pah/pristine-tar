//
// C++ Interface: settingsdialog
//
// Description: 
//
//
// Author: Lorn Potter <lorn.potter@gmail.com>, (C) 2006
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef SETTINGSDIALOG_H
#define SETTINGSDIALOG_H

#include "ui_settingsDialogBase.h"

#include <qdialog.h>

/**
    @author Lorn Potter <lorn.potter@gmail.com>
*/
class settingsDialogBase : public QDialog,  public Ui_settingsDialogBase
{
public:
    settingsDialogBase( QWidget *parent = 0, Qt::WFlags f = 0 );
    virtual ~settingsDialogBase();

};

class settingsDialog : public settingsDialogBase
{
    Q_OBJECT
public:
        settingsDialog( QWidget *parent = 0, Qt::WFlags f = 0 );
    virtual ~settingsDialog();

public slots:
    void fillSettingsTree( );
    
protected slots:
    void newMirrorList();
private:

    void readSettings();
private slots:
    void mirrorSelected(QTreeWidgetItem *, int);
    void doSelect();
private:
};

#endif
