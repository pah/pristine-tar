/* trivial */

#ifndef EXIT_H
#define EXIT_H

/*
extern void _exit();
*/
#include <unistd.h>

#endif
