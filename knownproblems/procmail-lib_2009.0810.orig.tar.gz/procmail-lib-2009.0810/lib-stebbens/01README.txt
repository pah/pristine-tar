lib-stebbens/01README.txt

        The original libraries were available (2002-01-02) from Alan's file
        server (there was no other download method known). The original
        request used was:

               Subject: send procmail lib
                    To: Alan K. Stebbens <alan.stebbens@openwave.com>

        If you have any questions concerning about programs or code in
        this directory, please contact Alan.

	NOTE: There is no support for these modules, so bug reports against
	them is probably in vain (unless you can contact Alan directly).

	-- 2008-09-19 Jari Aalto <jari.aalto@cante.net>

End
