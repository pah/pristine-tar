Psyco is a compiler that works in conjunction with Python
to speed up program execution, but it also increases memory
usage.  Edit PSYCO.py to enable/disable Psyco in the
client and utilities.