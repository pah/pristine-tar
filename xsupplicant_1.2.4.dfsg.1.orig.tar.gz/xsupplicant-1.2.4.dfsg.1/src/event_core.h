/*******************************************************************
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

#ifndef _EVENT_CORE_H_
#define _EVENT_CORE_H_

void event_core_init();
void event_core_deinit();
void event_core(struct interface_data *);

#endif
