/*******************************************************************
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: cardif_madwifi_driver.h
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

#ifdef ENABLE_MADWIFI

#ifndef _CARDIF_MADWIFI_DRIVER_H_
#define _CARDIF_MADWIFI_DRIVER_H_

extern struct cardif_funcs cardif_madwifi_driver;

int cardif_madwifi_driver_set_wpa_ie(char *, char *, int);
int cardif_madwifi_driver_wpa_enable(char *);
int cardif_madwifi_driver_wpa_disable(char *);
int cardif_madwifi_driver_set_key(char *, int, unsigned char *, int, int, 
				 char *, int, char *, int);
int cardif_madwifi_driver_wpa_state(struct interface_data *, char);
int cardif_madwifi_driver_disassociate(struct interface_data *, int);

#endif // _CARDIF_MADWIFI_DRIVER_H_

#endif // ENABLE_MADWIFI

