/*******************************************************************
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: cardif_linux_rtnetlink.c
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

#ifndef _CARDIF_LINUX_RTNETLINK_H_
#define _CARDIF_LINUX_RTNETLINK_H_

void cardif_linux_rtnetlink_init();
void cardif_linux_rtnetlink_cleanup();
u_char cardif_linux_rtnetlink_check_event(struct interface_data *,
					  struct wireless_state *);
void cardif_linux_rtnetlink_do_link(struct interface_data *,
				    struct nlmsghdr *, int, int,
				    struct wireless_state *);
void cardif_linux_rtnetlink_ifla_wireless(struct interface_data *, int, char *,
					  int, struct wireless_state *);
void cardif_linux_rtnetlink_check_custom(struct interface_data *, char *);

#endif
