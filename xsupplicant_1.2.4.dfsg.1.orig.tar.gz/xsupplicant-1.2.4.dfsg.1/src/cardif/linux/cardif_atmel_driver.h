/*******************************************************************
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: cardif_atmel_driver.h
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

#ifndef _CARDIF_ATMEL_DRIVER_H_
#define _CARDIF_ATMEL_DRIVER_H_

extern struct cardif_funcs cardif_atmel_driver;

int cardif_atmel_driver_wpa_enable(char *);
int cardif_atmel_driver_wpa_state(struct interface_data *, char);
int cardif_atmel_driver_wpa_disable(char *);
int cardif_atmel_driver_set_key(char *, int, unsigned char *, int, int, char *,
				int, char *, int);
int cardif_atmel_driver_disassociate(struct interface_data *, int);

#endif

