/*******************************************************************
 * The core linux event loop.
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: linux_core.h
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

#ifndef _CORE_H_
#define _CORE_H_

void ext_event_init();
void ext_event_core(struct interface_data *, struct wireless_state *);
void ext_event_deinit();

#endif

