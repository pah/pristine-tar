/*******************************************************************
 * EAPTTLS Phase 2 Function implementations
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: ttlsphase2.c
 *
 * Authors: Chris.Hessing@utah.edu
 *
 ******************************************************************/

#ifndef _TTLS_PHASE2_H
#define _TTLS_PHASE2_H

// Phase 2 Types for TTLS
#define TTLS_PHASE2_UNDEFINED 0
#define TTLS_PHASE2_PAP       1
#define TTLS_PHASE2_CHAP      2
#define TTLS_PHASE2_MSCHAP    3
#define TTLS_PHASE2_MSCHAPv2  4

void ttls_do_bogus(struct generic_eap_data *, char *, int *);
void ttls_do_pap(struct generic_eap_data *, char *, int *);
void ttls_do_chap(struct generic_eap_data *, char *, int *);
void ttls_do_mschap(struct generic_eap_data *, char *, int *);
void ttls_do_mschapv2(struct generic_eap_data *, char *, int *);
int ttls_do_phase2(struct generic_eap_data *, char *,int, char *, int *);
void ttls_phase2_failed(struct generic_eap_data *);

#endif
