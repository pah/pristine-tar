/*******************************************************************
 * Handle the keying state machine.
 *
 * Licensed under a dual GPL/BSD license.  (See LICENSE file for more info.)
 *
 * File: key_statemachine.h
 *
 * Authors: Chris.Hessing@utah.edu
 *
 *******************************************************************/

#ifndef _KEY_STATEMACHINE_H_
#define _KEY_STATEMACHINE_H_

//#include <stdint.h>
#include "profile.h"

#define RC4_KEY_TYPE       1
#define WPA2_KEY_TYPE      2
#define WPA_KEY_TYPE       254

void key_statemachine_run(struct interface_data *);


#endif

