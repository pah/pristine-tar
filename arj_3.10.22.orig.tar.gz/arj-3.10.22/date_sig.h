/*
 * $Id: date_sig.h,v 1.1.1.1 2002/03/28 00:02:10 andrew_belov Exp $
 * ---------------------------------------------------------------------------
 * This file declares references on data in DATE_SIG.C
 *
 */

#ifndef DATE_SIG_INCLUDED
#define DATE_SIG_INCLUDED

extern char build_date[];

#endif
