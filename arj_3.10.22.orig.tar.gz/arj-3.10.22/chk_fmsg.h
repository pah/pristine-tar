/*
 * $Id: chk_fmsg.h,v 1.1.1.1 2002/03/28 00:02:10 andrew_belov Exp $
 * ---------------------------------------------------------------------------
 * Prototypes of the functions located in CHK_FMSG.C are declared here.
 *
 */

#ifndef CHK_FMSG_INCLUDED
#define CHK_FMSG_INCLUDED

/* Prototypes */

void check_fmsg(int skip_check);

#endif

