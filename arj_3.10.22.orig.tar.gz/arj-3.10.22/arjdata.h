/*
 * $Id: arjdata.h,v 1.1.1.1 2002/03/28 00:01:19 andrew_belov Exp $
 * ---------------------------------------------------------------------------
 * Prototypes of the functions located in ARJDATA.C are declared here.
 *
 */

#ifndef ARJDATA_INCLUDED
#define ARJDATA_INCLUDED

char *expand_tags(char *str, int limit);

#endif
